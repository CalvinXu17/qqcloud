import{x as o,S as r,o as t,z as n}from"./index.59f76cad.js";const c={};function s(a,_){const e=r("router-view");return t(),n(e)}const f=o(c,[["render",s]]);export{f as default};
