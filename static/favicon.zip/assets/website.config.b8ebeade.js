const u="/assets/logo.7573b357.svg",e=Object.freeze({title:"\u7941\u542F\u4E91",logo:u,loginImage:u,loginDesc:"\u7941\u542F\u4E91\u514D\u8D39\u9A8C\u8BC1\u7CFB\u7EDF"});export{e as w};
