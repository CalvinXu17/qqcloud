import{E as e}from"./index.59f76cad.js";function o(t){return e.request({url:"/table/list",method:"post",params:t})}export{o as g};
