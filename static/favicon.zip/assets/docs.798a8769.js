import{x as c}from"./index.59f76cad.js";const r={};function e(t,n){return" \u9879\u76EE\u6587\u6863 "}const s=c(r,[["render",e]]);export{s as default};
