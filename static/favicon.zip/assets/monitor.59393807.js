import{x as e,o as c,c as o}from"./index.59f76cad.js";const n={};function r(t,s){return c(),o("div",null,"\u76D1\u63A7\u53F0")}const _=e(n,[["render",r]]);export{_ as default};
